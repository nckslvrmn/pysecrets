def handler(event, context):
    return True
